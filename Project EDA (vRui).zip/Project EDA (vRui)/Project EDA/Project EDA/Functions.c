/*****************************************************************//**
 * \file   Functions.c
 * \brief  Ficheiro que contem todas as fun�oes e procedimentos a ser utilizados na fun�ao main
 * \email  
 * \author 20844_Oscar Araujo / 20845_Elson Simoes / 21674_Rui Lopes
 * \date   24 March 2021
 *********************************************************************/

#include "Files.h"


 /**
  * mostraFuncoes:
  * Procedimento para mostrar menu de op��es disponiveis de executar
  */
void mostraFuncoes()
{
	printf("=================================\n");
	printf("Software de Atribuicao de Vagas\n");
	printf("[1] Listar Dados Pacientes\n");
	printf("[2] Listar Hospitais e vagas livres\n");
	printf("[3] Gerir Pacientes com erros de dados\n");
	printf("[4] Gerir Vagas de Hospitais\n");
	printf("[5] Atribuir vagas e mostrar resultado\n");
	printf("[0] Terminar Software\n");
	printf("Escolha uma opcao: ");
}

/**
 * Fun��o que abre o ficheiro txt com a Lista dos Pacientes, valida se tudo correu bem e carrega para uma lista ligada
 * \param tipoUnidades
 * \param size
 */
Hospitais* carregadbHospitais(Pacientes* lista, int* erro)
{
	FILE* dbHospitais; //cria um apontador do tipo file
	dbHospitais = fopen(PATH_DB_HOSPITAIS, "r");

	if (dbHospitais == NULL) return (*erro - 1); //erro de abertura do ficheiro
	else {
		char str[100]
			, delimiter[1] = ";" //define o delimitador ";" que separa as colunas do ficheiro txt
			, endOfLine[2] = "\n"; //define o delimitador fim da linha \n, usamos este delimitador quando lemos a ultima coluna, caso contrario se for uma string ela guarda o caracter \n junto com a string

		Hospitais* listaHosp = (Hospitais*)malloc(sizeof(Hospitais));
		while (fgets(str, sizeof(str), dbHospitais) != NULL)
		{
			if (listaHosp != NULL)
			{
				strcpy(listaHosp->nome, strtok(str, delimiter));
				listaHosp->vagas = atoi(strtok(NULL, delimiter)); //como a fun��o strok l� uma string, para converter para um inteiro o ID usamos a fun��o atoi que faz o cast de string para int;
			}
			lista = insereHospInicio(lista, listaHosp);
		}
		
		fclose(dbHospitais); //no fim de abrir o documento e passar o conte�do para a lista, fechamos o file e gravamos
		return (lista);
	}
}

 /**
  * Fun��o que abre o ficheiro txt com a Lista dos Pacientes, valida se tudo correu bem e carrega para uma lista ligada
  * \param tipoUnidades
  * \param size
  */
void carregadbPacientes(Pacientes** lista, Pacientes** listaErros, int *erro)
{
	FILE* dbPacientes; //cria um apontador do tipo file
	dbPacientes = fopen(PATH_DB_PACIENTES, "r");

	if (dbPacientes == NULL) { return (*erro -1); } //erro de abertura do ficheiro
	else {
		char str[100]
			, delimiter[1] = ";" //define o delimitador ";" que separa as colunas do ficheiro txt
			, endOfLine[2] = "\n"; //define o delimitador fim da linha \n, usamos este delimitador quando lemos a ultima coluna, caso contrario se for uma string ela guarda o caracter \n junto com a string

		Pacientes* checkErros = (Pacientes*)malloc(sizeof(Pacientes));
		while (fgets(str, sizeof(str), dbPacientes) != NULL)
		{
			if (checkErros != NULL)
			{
				checkErros->numSNS = atoi(strtok(str, delimiter)); //como a fun��o strok l� uma string, para converter para um inteiro o ID usamos a fun��o atoi que faz o cast de string para int;
				strcpy(checkErros->nome, strtok(NULL, delimiter));
				for (int i = 0; i <= 4; i++)
				{
					strcpy(checkErros->preferencia[i].preferencia, strtok(NULL, delimiter));
					checkErros->preferencia[i].distancia = atoi(strtok(NULL, delimiter));					
				}
				strcpy(checkErros->vaga, "-");
				strcpy(checkErros->dados, "-");
			}
			//lista = inserePacInicio(lista, checkErros);
			//lista = inserePacFim(lista, checkErros, &listaErros);
			checkErrosPac(lista, checkErros, listaErros);

		}
		fclose(dbPacientes); //no fim de abrir o documento e passar o conte�do para a lista, fechamos o file e gravamos
	}
}


/**
 * procuraErros:
 * Fun��o que dada um elemento de uma lista de pacientes procura a existencia de erros nos dados fornecidos pelo mesmo
 * \param lista -->Recebe elemento da lista ligada de pacientes
 * \return --> 0 se contiver erros || 1 se estiver tudo completo e correto
 */
void checkErrosPac(Pacientes** listaPrincipal, Pacientes* checkErros, Pacientes** listaErros)
{
	boolean nSNSExist;
	if (checkErros->numSNS == NULL || checkErros->numSNS == 0) {
		strcpy(checkErros->dados, "Erro: NumSNS");
		inserePacInicio(checkErros, listaErros);
	}
	else
	{
		nSNSExist = checkNumSNSExist(listaPrincipal, checkErros->numSNS);
		if (nSNSExist == true) {
			strcpy(checkErros->dados, "Erro: NumSNS");
			inserePacInicio(listaErros, checkErros);
		}
		else if (checkErros->preferencia[0].preferencia == NULL || checkErros->preferencia[0].distancia == NULL || 
			checkErros->preferencia[0].distancia == 0) {
			strcpy(checkErros->dados, "Erro: Pref1");
			inserePacInicio(listaErros, checkErros);
		}
		else inserePacInicio(listaPrincipal, checkErros);
	}
}

boolean checkNumSNSExist(Pacientes** lista, int numSNS)
{
	if (*lista == NULL ) return false;
	else
	{
		Pacientes* temp = *lista;
		while (temp != NULL)
		{
			if (numSNS == temp->numSNS ) return true;
			temp = temp->proximo;
		}
		return false;
	}
}

/**
 * inserePacienteInicio:
 * Fun��o que dada uma lista de pacientes insere no inicio um paciente
 * \param lista -->Lista de pacientes a editar
 * \param entrada -->Paciente do tipo struct a inserir
 * \return -->Devolve a lista com o paciente inserido se for possivel
 */
void inserePacInicio(Pacientes** lista, Pacientes* entrada)
{
	Pacientes* novo = (Pacientes*)malloc(sizeof(Pacientes));
	if (novo != NULL)
	{
		novo->numSNS = entrada->numSNS;
		strcpy(novo->nome, entrada->nome);
		for (int i = 0; i <= 4; i++)
		{
			strcpy(novo->preferencia[i].preferencia, entrada->preferencia[i].preferencia);
			novo->preferencia[i].distancia = entrada->preferencia[i].distancia;
		}
		strcpy(novo->vaga, entrada->vaga);
		strcpy(novo->dados, entrada->dados);

		novo->proximo = *lista;
		*lista = novo;
	}
}


/**
 * inserePacFim
 * Fun��o que dada uma lista de pacientes insere no fim um paciente
 * \param lista -->Lista de pacientes a editar
 * \param entrada -->Paciente do tipo struct a inserir
 * \return -->Devolve a lista com o paciente inserido se for possivel
 */
void inserePacFim(Pacientes** lista, Pacientes* entrada)
{
	Pacientes* novo = (Pacientes*)malloc(sizeof(Pacientes));
	Pacientes* temp = *lista;
	if (novo != NULL)
	{
		novo->numSNS = entrada->numSNS;
		strcpy(novo->nome, entrada->nome);
		for (int i = 0; i <= 4; i++)
		{
			strcpy(novo->preferencia[i].preferencia, entrada->preferencia[i].preferencia);
			novo->preferencia[i].distancia = entrada->preferencia[i].distancia;
		}		
		novo->proximo = NULL;

		if (temp == NULL) { return novo; }
		else
		{
			while (temp->proximo != NULL) temp = temp->proximo;
			temp->proximo = novo;
			*lista = novo;
		}
	}
}


/**
 * inserePacienteInicio:
 * Fun��o que dada uma lista de pacientes insere no inicio um paciente
 * \param lista -->Lista de pacientes a editar
 * \param entrada -->Paciente do tipo struct a inserir
 * \return -->Devolve a lista com o paciente inserido se for possivel
 */
Hospitais* insereHospInicio(Hospitais* lista, Hospitais* entrada)
{
	Hospitais* novo = (Hospitais*)malloc(sizeof(Hospitais));
	if (novo != NULL)
	{		
		strcpy(novo->nome, entrada->nome);
		novo->vagas = entrada->vagas;

		novo->seguinte = lista;
		lista = novo;
	}
	return (lista);
}


/**
 * listarHospitais:
 * Procedimento para listar no ecra todos os hospitais carregados do ficheiro
 * \param inicio -->Recebe uma lista ligada de hospitais
 */
void listarHospitais(Hospitais* lista)
{
	Hospitais* aux = lista; //cria um apontador que ir� apontar para o inicio
	printf("\nNOME\t  VAGAS \n");
	while (aux != NULL)
	{
		printf("%1s\t %-4d \n", aux->nome, aux->vagas);
		aux = aux->seguinte; //aux ficar� com o valor do pr�ximo elemento
	}
}

/**
 * listar:
 * Procedimento para listar no ecra todos os pacientes carreegados por ficheiro assim como todos os seus dados
 * \param inicio -->Recebe uma lista ligada de pacientes
 */
void listarPacientes(Pacientes* lista)
{
	Pacientes* aux = lista; //cria um apontador que ir� apontar para o inicio
	printf("\nID\t NOME\t  PREF1\t  DIST\t PREF2\t DIST\t PREF3\t  DIST\t PREF4\t  DIST\t PREF5\t DIST\t VAGA \t OBSERVACOES \n");
	while (aux != NULL)
	{
		printf("%-5d\t %-10s %2s\t %4d\t %2s\t %4d\t  %2s\t %4d\t %2s\t  %4d\t  %2s\t %-4d\t %-6s\t %-15s \n",
			aux->numSNS, aux->nome, aux->preferencia[0].preferencia, aux->preferencia[0].distancia, aux->preferencia[1].preferencia,
			aux->preferencia[1].distancia, aux->preferencia[2].preferencia, aux->preferencia[2].distancia, aux->preferencia[3].preferencia,
			aux->preferencia[3].distancia, aux->preferencia[4].preferencia, aux->preferencia[4].distancia, aux->vaga, aux->dados);

		aux = aux->proximo; //aux ficar� com o valor do pr�ximo elemento
	}
}




/*****************************************************************//**
 * \file   Files.h
 * \brief  Header file que contem todas as assinaturas de fun�oes e defini�oes de tipos de dados
 * \email  
 * \author 20844_Oscar Araujo / 20845_Elson Simoes / 21674_Rui Lopes
 * \date   24 March 2021
 *********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h> //lib para manipular strings

#pragma region Defines
#pragma warning (disable:4996) // desativa os warings referentes ao printf e scanf
#define PATH_DB_PACIENTES "DataBase\\pacientes.txt" // Define o caminho do ficheiro dos pacientes
#define PATH_DB_HOSPITAIS "DataBase\\hospitais.txt" // Define o caminho do ficheiro dos hospitais
#define MAXNOME 30


#pragma endregion

//Cria�ao de tipos de dados a utilizar no nosso c�digo
#pragma region Tipos de Dados
typedef enum { false, true }boolean; //tipo de dados boolean (true, false)

//estrutura criada para guardar as prefer�ncias e dist�ncias de cada paciente
typedef struct preferencias {
    char preferencia[1];
    int distancia;
}Preferencias;

typedef struct pacientes {
    int numSNS;
    char nome[MAXNOME];
    Preferencias preferencia[5];
    char vaga[10];
    char dados[20];
    struct pacientes *proximo;
    //Pacientes* anterior;
}Pacientes;

typedef struct vagas
{
    int numSNS;
    Pacientes* utente;
    struct vagas* seguinte;
} Vagas;

typedef struct Hospitais
{
    char nome[1];
    int vagas;
    struct Hospitais* seguinte;
    struct vagas* listaVagas;
} Hospitais;



#pragma endregion

//Assinaturas das fun�oes/procedimentos criados e a ser chamadas no main
#pragma region Assinaturas de Fun�oes

void carregadbPacientes(Pacientes** lista, Pacientes** listaErros, int* erro);
Hospitais* carregadbHospitais(Pacientes* lista, int* erro);
void checkErrosPac(Pacientes** listaPrincipal, Pacientes* checkErros, Pacientes** listaErros);
boolean checkNumSNSExist(Pacientes* lista, int numSNS);
Hospitais* insereHospInicio(Hospitais* lista, Hospitais* entrada);
void inserePacInicio(Pacientes** lista, Pacientes* entrada);
void inserePacFim(Pacientes** lista, Pacientes* entrada);
void listarPacientes(Pacientes* inicio);
void listarHospitais(Hospitais* lista);
void mostraFuncoes();








#pragma endregion